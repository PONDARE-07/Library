<?php
include("conFunc.php");
error_reporting(0);
?>
<?php if($_SESSION['login']!="")
{?>
    <?php } ?>
    <!-- HEADER END-->
    <div class="navbar navbar-inverse set-radius-zero">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

<div class="left-div">
                <a class="navbar-brand"  style="color:#fff; font-size:25px;4px; line-height:26px; font:monospace;">Welcome to Asistencia Aklatan</a>
            </div>
            <br>
            <br>
            <div class="left-div">
                             <img src = "images/banner_library.png" width = "190px" height = "50px" />

        </div>
                

            </div>

            </div>
        </div>