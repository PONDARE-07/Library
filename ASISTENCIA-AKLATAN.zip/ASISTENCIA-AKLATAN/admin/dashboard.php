<?php
    include 'conFunc.php';
?>
<!DOCTYPE html>
<html lang = "en">
    <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
<meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/start.css"/>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
    
        <meta charset = "utf-8" />
        <meta name = "viewport" content = "width=device-width, initial-scale=1" />
    </head>

<body style = "background-color:#d3d3d3;">
    <?php include('includes/header.php');?>
    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4 class="page-head-line">VISUALIZATIONS</h4>
                </div>
 <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">Dashboard</h1>
                        <div class="row">
                        	
                            <div class="col-md-3 col-sm-3 col-xs-6">
                      <div class="alert alert-success back-widget-set text-center">

                            <i class="fa fa-users fa-5x"></i>
<?php 
$con = mysqli_connect('localhost','root','','librarydb');
$query = "SELECT count(*) AS counts from visitors 
while ($counts) {
    ['row']} ";
 
$result = mysqli_query($con, $query);
$listvisit = $result;
echo($listvisit);
?>

                            <h3></h3>
                        <a class="small text-black stretched-link" href="#"><h3>Total Number of Visits</h3></a>
                        </div>
                    </div>

<div class="col-md-3 col-sm-3 col-xs-6">
                     <div class="alert alert-info back-widget-set text-center">

                            <i class="fa fa-bars fa-5x"></i>
<?php 
$con = mysqli_connect('localhost','root','','librarydb');
$query = "SELECT id from visitors ";

$result = mysqli_query($con, $query);
?>
                            <h3><?php echo htmlentities($listvisit);?></h3>
                          <a class="small text-black stretched-link" href="#"><h3>Most Availed Service</h3></a>
                        </div>
                    </div>

<div class="col-md-3 col-sm-3 col-xs-6">
                     <div class="alert alert-info back-widget-set text-center">

                            <i class="fa fa-bars fa-5x"></i>
<?php 
$con = mysqli_connect('localhost','root','','librarydb');
$query = "SELECT id from visitors ";

$result = mysqli_query($con, $query);
?>
                            <h3><?php echo htmlentities($listvisit);?></h3>
                          <a class="small text-black stretched-link" href="#">Most Availed Service</a>
                        </div>
                    </div>


                        <div class="row">
                            <div class="col-xl-6">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <i class="fas fa-chart-area me-1"></i>
                                        Area Chart Example
                                    </div>
                                    <div class="card-body"><canvas id="myAreaChart" width="100%" height="40"></canvas></div>
                                </div>
                            </div>
                            <div class="col-xl-6">
                                <div class="card mb-4">
                                    <div class="card-header">
                                        <i class="fas fa-chart-bar me-1"></i>
                                        Bar Chart Example
                                    </div>
                                    <div class="card-body"><canvas id="myBarChart" width="100%" height="40"></canvas></div>
                                </div>
                            </div>
                        </div>

</div>
                </div>
</div>
</div>
</div>
</div>
<?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- DATATABLE SCRIPTS  -->
    <script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
     </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@latest" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
</body>
</html>