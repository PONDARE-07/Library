<section class="menu-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse">
                        <ul id="menu-top" class="nav navbar-nav navbar-left">
                            <ul class="nav nav-pills nav-fill">
                            <li>"                            "</li>
                             <li><a href="admin/adminlogin.php">LIBRARIAN</a></li>
                             <li>____________</li>
                             <li><a href="enroll-history.php">LIBRARIAN STAFF</a></li>
                             <li>____________</li>
                             <li><a href="studlog.php">STUDENTS</a></li>
                             <li>____________</li>
                             <li><a href="facultylog.php">FACULTY/INSTRUCTOR</a></li>
                             <li>____________</li>
                             <li><a href="visitors.php">VISITORS   </a></li>
                             
                             

                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>