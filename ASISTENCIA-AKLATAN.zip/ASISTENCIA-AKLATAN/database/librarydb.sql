-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 04, 2022 at 04:41 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `librarydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `department_name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `department_id`, `department_name`) VALUES
(1, 1, 'CICS'),
(2, 101, 'CAS'),
(3, 102, 'CABEIHM');

-- --------------------------------------------------------

--
-- Table structure for table `librarian`
--

CREATE TABLE `librarian` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `librarian`
--

INSERT INTO `librarian` (`username`, `password`) VALUES
('admin@mail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `program`
--

CREATE TABLE `program` (
  `id` int(11) NOT NULL,
  `program_code` varchar(255) NOT NULL,
  `program_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `program`
--

INSERT INTO `program` (`id`, `program_code`, `program_name`) VALUES
(1, 'BSIT', 'Bachelor of Science in Information Technology'),
(2, 'BSA', 'Bachelor of Science in Accountancy'),
(3, 'BSED', 'Bachelor of Science in Education ');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `service_no.` int(50) NOT NULL,
  `service_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`service_no.`, `service_name`) VALUES
(1, 'Internet'),
(2, 'Circulation'),
(3, 'Referral');

-- --------------------------------------------------------

--
-- Table structure for table `student_history`
--

CREATE TABLE `student_history` (
  `student_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `time_in` time NOT NULL,
  `time_out` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_history`
--

INSERT INTO `student_history` (`student_id`, `service_id`, `time_in`, `time_out`) VALUES
(2, 2, '19:15:39', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE `student_info` (
  `id` int(11) NOT NULL,
  `sr_code` varchar(8) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `department_id` int(11) NOT NULL,
  `program_code` int(250) NOT NULL,
  `section` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_info`
--

INSERT INTO `student_info` (`id`, `sr_code`, `firstname`, `lastname`, `department_id`, `program_code`, `section`) VALUES
(2, '19-73563', 'Christine Mae', 'Cahayon', 101, 3, '1102'),
(3, '19-77824', 'Rodelyn', 'Pondare', 102, 2, '1103'),
(5, '19-38767', 'Karina', 'Sta. Ana', 101, 3, '1102'),
(6, '19-32463', 'Calvin', 'Sirena', 102, 3, '1103'),
(7, '19-78437', 'Siria', 'Calamba', 102, 3, '1103'),
(8, '19-77824', 'Rodelyn', 'Pondare', 1, 1, '1101'),
(9, '19-77825', 'Karen', 'Quizana', 101, 3, '1101'),
(10, '19-77826', 'Arnold', 'Bausas', 1, 1, '1101'),
(11, '19-77827', 'Fatima', 'De Ore', 1, 2, '1101'),
(12, '19-77828', 'Nicole', 'Sanchez', 101, 1, '1101'),
(13, '19-77829', 'Sheila', 'Perez', 1, 2, '1101'),
(14, '19-77830', 'Caleb', 'Dominic', 102, 3, '1101'),
(15, '19-77831', 'Lucius', 'Comodeus', 1, 3, '1101'),
(16, '19-77832', 'Ashley', 'Catapang', 102, 1, '1101'),
(17, '19-77833', 'Dona Mae', 'De Jesus', 1, 1, '1101'),
(18, '19-77834', 'Maribel', 'Panganiban', 101, 1, '1101'),
(19, '19-77835', 'Christine Mae', 'Cahayon', 101, 2, '1101'),
(20, '19-77836', 'Perwin', 'Bausas', 1, 2, '1101'),
(21, '19-77837', 'Joshua', 'Villanueva', 1, 2, '1101'),
(22, '19-77838', 'Agnes', 'Velasquez', 102, 1, '1101'),
(23, '19-77839', 'Rael', 'Mabuhay', 102, 1, '1101'),
(24, '19-77840', 'Asher', 'Delfeo', 1, 1, '1101'),
(25, '19-77841', 'Zeus', 'Neri', 1, 3, '1101'),
(26, '19-77842', 'Reynan', 'Bermudo', 101, 1, '1101'),
(28, '19-77825', 'Karen', 'Quizana', 101, 3, '1101'),
(29, '19-77826', 'Arnold', 'Bausas', 1, 1, '1101'),
(30, '19-77827', 'Fatima', 'De Ore', 1, 2, '1101'),
(31, '19-77828', 'Nicole', 'Sanchez', 101, 1, '1101'),
(32, '19-77829', 'Sheila', 'Perez', 1, 2, '1101'),
(33, '19-77830', 'Caleb', 'Dominic', 102, 3, '1101'),
(34, '19-77831', 'Lucius', 'Comodeus', 1, 3, '1101'),
(35, '19-77832', 'Ashley', 'Catapang', 102, 1, '1101'),
(36, '19-77833', 'Dona Mae', 'De Jesus', 1, 1, '1101'),
(37, '19-77834', 'Maribel', 'Panganiban', 101, 1, '1101'),
(38, '19-77835', 'Christine Mae', 'Cahayon', 101, 2, '1101'),
(39, '19-77836', 'Perwin', 'Bausas', 1, 2, '1101'),
(40, '19-77837', 'Joshua', 'Villanueva', 1, 2, '1101'),
(41, '19-77838', 'Agnes', 'Velasquez', 102, 1, '1101'),
(42, '19-77839', 'Rael', 'Mabuhay', 102, 1, '1101'),
(43, '19-77840', 'Asher', 'Delfeo', 1, 1, '1101'),
(44, '19-77841', 'Zeus', 'Neri', 1, 3, '1101'),
(45, '19-77842', 'Reynan', 'Bermudo', 101, 1, '1101');

-- --------------------------------------------------------

--
-- Table structure for table `student_time_history`
--

CREATE TABLE `student_time_history` (
  `sr_code` int(50) NOT NULL,
  `time_in` int(50) NOT NULL,
  `time_out` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `visitors`
--

CREATE TABLE `visitors` (
  `id` int(11) NOT NULL,
  `visitors_name` varchar(50) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `date_entered` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `visitors`
--

INSERT INTO `visitors` (`id`, `visitors_name`, `purpose`, `date_entered`) VALUES
(1, 'Ana Onuma', 'Visitation', '2022-07-27 21:54:14'),
(2, 'Rachelle Pondare', 'Others', '2022-07-29 15:11:43'),
(3, 'Cahayon Christine Mae', 'Visitation', '2022-07-30 06:28:39'),
(4, 'Maribel Panganiban A.', 'Others', '2022-07-30 06:40:45'),
(5, 'Nicole Dasmarinas C.', 'Visitation', '2022-07-30 06:53:36');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `department_id_idx` (`department_id`);

--
-- Indexes for table `librarian`
--
ALTER TABLE `librarian`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `program`
--
ALTER TABLE `program`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`service_no.`);

--
-- Indexes for table `student_history`
--
ALTER TABLE `student_history`
  ADD KEY `student_history_ibfk_1` (`student_id`),
  ADD KEY `student_history_ibfk_2` (`service_id`);

--
-- Indexes for table `student_info`
--
ALTER TABLE `student_info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `department_id` (`department_id`),
  ADD KEY `program_code` (`program_code`);

--
-- Indexes for table `student_time_history`
--
ALTER TABLE `student_time_history`
  ADD PRIMARY KEY (`sr_code`);

--
-- Indexes for table `visitors`
--
ALTER TABLE `visitors`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `program`
--
ALTER TABLE `program`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `service_no.` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `student_info`
--
ALTER TABLE `student_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `student_time_history`
--
ALTER TABLE `student_time_history`
  MODIFY `sr_code` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `visitors`
--
ALTER TABLE `visitors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `student_history`
--
ALTER TABLE `student_history`
  ADD CONSTRAINT `student_history_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `student_info` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `student_history_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `services` (`service_no.`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `student_info`
--
ALTER TABLE `student_info`
  ADD CONSTRAINT `student_info_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `department` (`department_id`),
  ADD CONSTRAINT `student_info_ibfk_2` FOREIGN KEY (`program_code`) REFERENCES `program` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
