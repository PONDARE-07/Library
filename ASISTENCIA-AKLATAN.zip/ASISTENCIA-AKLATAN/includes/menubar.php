<section class="menu-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse">
                        <ul id="menu-top" class="nav navbar-nav navbar-left">
                            <ul class="nav nav-pills nav-fill">
                            <li>"                            "</li>
                             <li><a href="admin/adminlogin.php"><h3>LIBRARIAN</h3></a></li>
                             <li>____________</li>
                             <li><a href="staff/index_staff.php"><h3>LIBRARIAN STAFF</h3></a></li>
                             <li>____________</li>
                             <li><a href="student/studlog.php"><h3>STUDENT</h3></a></li>
                             <li>____________</li>
                             <li><a href="facultylog.php"><h3>FACULTY/INSTRUCTOR</h3></a></li>
                             <li>____________</li>
                             <li><a href="visitors/index_visitors.php"><h3>VISITORS</h3></a></li>
                             
                             

                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>