<!DOCTYPE html>
<html lang = "en">
<head>

	  <meta charset="utf-8">
	  <meta http-equiv="X-UA-Compatible" content="IE=edge">
	  <meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Start Page</title>
	<link rel="stylesheet" href="css\start.css"/>
	
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		
	<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>	
	
</head>
<body>

			<div style="background-color: #ebeef7" class="center">
			<h1>Choose</h1>
			<a href="admin.php">
			<button class="button" type="button" class="btn btn-default">Admin</button>
			</a>
			<br>
			<a href="users.php">
			<button class="button" type="button" class="btn btn-default">User</button>
			</div>
			</a>

</body>
</html>